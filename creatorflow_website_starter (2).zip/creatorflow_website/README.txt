CreatorFlow starter website
============================

Files
-----
index.html — the complete responsive starter website. It uses plain HTML and CSS, with no paid libraries or build step.

Preview on your computer
------------------------
1. Extract the ZIP file.
2. Open index.html in Chrome, Edge, or Firefox.

Publish for free with GitHub Pages
----------------------------------
1. Create/sign in to a GitHub account at https://github.com/
2. Create a new PUBLIC repository, e.g. creatorflow-website.
3. Upload index.html to the root of the repository.
4. Open the repository's Settings → Pages.
5. Under Build and deployment, choose "Deploy from a branch".
6. Choose the main branch and /(root), then Save.
7. Wait for GitHub Pages to publish and follow the URL shown on the Pages settings screen.

Important
---------
- This is a website starter, not a live hosted site until you publish it.
- GitHub Pages offers free static hosting for public repositories; check GitHub's current plan terms.
- No custom domain is included. You can use the free GitHub Pages address initially.
- The website currently has no mailing-list backend, database, or real analytics integration.
- The call-to-action is a placeholder link to TikTok. Replace it with your own public profile or a real feedback form before launch.
- The dashboard is a visual concept, not a functioning app.
- Review all text before publishing and remove any personal information you do not want public.
